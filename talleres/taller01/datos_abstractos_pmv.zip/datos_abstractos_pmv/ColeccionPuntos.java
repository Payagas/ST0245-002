import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * En esta clase se maneja una colección de datos.
 * Se utiliza un ArrayList
 *
 * @author Pablo Maya
 * @version Mayo, 2020
 */
public class ColeccionPuntos
{
    /**
     * Este es el array que guarda todas los datos.
     */
    protected ArrayList<Punto> al;

    /**
     * Constructor de la clase ColeccionDatos.
     * Se inicializa el ArrayList de datos.
     * 
     */
    public ColeccionPuntos() {
        al = new ArrayList<>();
    }

    /**
     * Este método lee un archivo con datos desde el disco.
     * El nombre del archivo se le pregunta al usuario.
     * Los datos quedan guardados en el ArrayList de datos.
     * 
     * @param nombreArchivo Nombre del archivo a leer
     * @throws FileNotFoundException La excepción se lanza si el archivo
     * que el usuario quiere leer no existe.
     */
    public void leerArchivo(String nombreArchivo) throws FileNotFoundException {
        Scanner archivo = new Scanner(new File(nombreArchivo));
        while(archivo.hasNextLine()) {
            String linea = archivo.nextLine();
            Scanner sl = new Scanner(linea);
            boolean esc = false;
            while (sl.hasNext()) {
                try {
                    double id = sl.nextDouble();
                    if(sl.hasNext()){
                        double x = sl.nextDouble();
                        if(sl.hasNext()){
                            double y = sl.nextDouble();
                            al.add(new Punto(x,y));
                        }
                    }
                } catch (InputMismatchException e) {
                    System.out.print(e.getMessage()); 
                    esc = true;
                }
                if(esc)break;
            }
        }
    }

    /**
     * Método para obtener el array.
     */
    public ArrayList<Punto> getArray(){
        return al;
    }

    /**
     * Método para obtener el numero de datos en el array.
     */
    public int getSize(){
        return al.size();
    }
}
