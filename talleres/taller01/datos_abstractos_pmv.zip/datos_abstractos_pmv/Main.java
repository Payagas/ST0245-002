/**
 * Clase principal.
 *
 * @author Pablo Maya
 * @version Julio, 2020
 */
public class Main
{
    public static void main (String[]args){
        Procesador p = new Procesador();
        p.opciones();
    }
}
